package com.pock.poc_otp_auto_read

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

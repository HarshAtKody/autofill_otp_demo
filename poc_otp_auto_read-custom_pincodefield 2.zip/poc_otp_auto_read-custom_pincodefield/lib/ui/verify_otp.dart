import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'package:telephony/telephony.dart';

class VerifyOTPScreen extends StatefulWidget {
  final String? signatureId;
  const VerifyOTPScreen({Key? key, this.signatureId}) : super(key: key);

  @override
  State<VerifyOTPScreen> createState() => _VerifyOTPScreenState();
}

class _VerifyOTPScreenState extends State<VerifyOTPScreen> with CodeAutoFill{
  TextEditingController otpCtr = TextEditingController();



  @override
  void codeUpdated() {
    print("Update code $code");
    if(mounted) {
      setState(() {
        otpCtr.text = code ?? '';
        print("codeUpdated");
      });
    }
  }

  @override
  void initState() {
    // SmsAutoFill().listenForCode;
    listenForCode();
    print("OTP listen Called");
    super.initState();
  }

  @override
  Future<void> dispose() async {
    super.dispose();
    await cancel();
    await unregisterListener();
    print("unregisterListener");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(widget.signatureId ?? "", style: TextStyle(fontSize: 16),),
            Center(
              child: TextField(
                controller: otpCtr,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  hintText: "Enter Otp",
                ),
                inputFormatters: [
                  LengthLimitingTextInputFormatter(6),
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text("Verify OTP")),
          ],
        ),
      ),
    );
  }
}

class OtpPhoneWidget extends StatefulWidget {
  const OtpPhoneWidget({
    Key? key,
  }) : super(key: key);

  @override
  _OtpPhoneWidgetState createState() => _OtpPhoneWidgetState();
}

class _OtpPhoneWidgetState extends State<OtpPhoneWidget>
    with TickerProviderStateMixin {

  String otp = '';
  Telephony telephony = Telephony.instance;
  OtpFieldController otpbox = OtpFieldController();

  final scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  void initState() {
    telephony.listenIncomingSms(
      onNewMessage: (SmsMessage message) {
        print(message.address);
        print(message.body);

        String sms = message.body.toString();

        if (message.body!.contains('otp-read-854a7.firebaseapp.com')) {

          String otpcode = sms.replaceAll(new RegExp(r'[^0-9]'), '');
          otpbox.set(otpcode.split(""));
          print('otpcodeotpcodeotpcode $otpcode');
          setState(() {
            // refresh UI
          });
        } else {
          print("error");
        }
      },
      listenInBackground: false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text('Otp Aut0fill'),
      ),
      body: Center(
        child: Column(
          children: [
            OTPTextField(
              outlineBorderRadius: 10,
              controller: otpbox,
              length: 6,
              width: MediaQuery.of(context).size.width,
              fieldWidth: 50,
              style: TextStyle(fontSize: 17),
              textFieldAlignment: MainAxisAlignment.spaceAround,
              fieldStyle: FieldStyle.box,
              onCompleted: (pin) {
                otp = pin;

              },
            ),
          ],
        ),
      ),
    );
  }
}


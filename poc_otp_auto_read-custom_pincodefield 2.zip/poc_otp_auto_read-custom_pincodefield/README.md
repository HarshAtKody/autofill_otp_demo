# poc_otp_auto_read
 otp auto read with the sms autofill packge using app signature id
